1.The first part of the code is Calculating Entropy.
2.The second part deals with building decision trees from Information Gain.
3.The third code structure deals with the Iris Dataset - Efficient Neural Network & Feature Contribution Analysis.
4. The fourth part of the code structure deals with Building & Training Neural Network.
5. The following blocks Evaluate the model, feature selection using backward search& also monitoring the training loss with Epochs.   
